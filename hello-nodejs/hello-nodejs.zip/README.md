# Mini CodeJam (1 hour)

## CPL628	Getting Started with Cloud Foundry on SAP Cloud Platform

In this session, you will learn more about Cloud Foundry. In particular, you will get familiar with:
 - the cockpit
 - the official CF CLI
 - some Cloud Foundry core concepts like pushing an app, binding a service, scaling the app, etc.

Detailed steps description for the session: [Mini CodeJam](/exercises/basic-codeJam)
